package ggkaw.caces.doby;

import java.util.*;

public class CourseInstance {
    int day;
    // now instead we have startTime and endTime instead of hour minute
    int hour;
    int minute;
    int duration; // in minutes
    String type;

    public CourseInstance(int day, int hour, int minute, int duration, String type) {
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.duration = duration;
        this.type = type;
    }

    void printCI() {
        System.out.print("Day: " + day);
        System.out.print(", Hour: " + hour);
        System.out.print(", Minute: " + minute);
        System.out.print(", Duration: " + duration);
        System.out.println(", Type: " + type);
    }

    private dayIntConvert(String day) {

    }

    private timeConvert()


}

