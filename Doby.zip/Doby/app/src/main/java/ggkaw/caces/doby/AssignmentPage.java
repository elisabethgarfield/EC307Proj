package ggkaw.caces.doby;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.CalendarView;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class AssignmentPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment_page);
        CalendarView mCalendarView = (CalendarView) findViewById(R.id.Calendar_View);
        final TextView dateView = (TextView) findViewById(R.id.testTextView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                String date = year + "/" + (month+1) + "/" + dayOfMonth;
                dateView.setText(date);

            }
        });





//    CalendarView Cview = (CalendarView) findViewById(R.id.Calendar_View);
//    Cview.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
//        GregorianCalendar calendar;
//        @Override
//        public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
//            this.calendar = new GregorianCalendar( year, month, dayOfMonth );
//        }
//    });
//
//    Calendar c = Calendar.getInstance();
//    c.setTimeInMillis(Cview.getDate());
//
//    String s = "THE DAY OF THE MONTH SELECTED IS ";
//    s.concat(Integer.toString(c.get(Calendar.DAY_OF_MONTH));
//
//    Log.d("CALENDAR DAY", s);
////    System.out.println(c.get(Calendar.DAY_OF_MONTH));



    }
}
