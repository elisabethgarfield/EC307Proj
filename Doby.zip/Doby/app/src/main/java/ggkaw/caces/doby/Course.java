package ggkaw.caces.doby;

import java.util.*;

//5 instances at any given time
public class Course {
    String name;
    String startDate;
    String endDate;
    Vector<CourseInstance> classTimes = new Vector(); // row 1 holds times it meets, row 2 holds duration, row 3 holds lec, lab, HW
    int numInstances;
    double multiplier; // absolute conversion rate (GPA/time)
// eventually add grade breakdown??

    public Course(String name, Vector<CourseInstance> classTimes, double multiplier) {
        this.name = name;
        for (int i = 0; i < classTimes.size(); i++) {
            this.classTimes.add(classTimes.get(i));
        }
        this.multiplier = multiplier;
    }

    public Course(String name, double multiplier, String startDate, String endDate) {
        this.name = name;
        this.classTimes = new Vector<CourseInstance>();
        this.multiplier = multiplier;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    void addInstance(CourseInstance newInstance) {
        // add a new instance to the classTimes
        classTimes.add(newInstance);
    }

    CourseInstance removeInstance(int idx) {
        // remove class instance at index idx
        CourseInstance removedCourse = classTimes.get(idx);
        classTimes.remove(idx);
        return removedCourse;
    }

    void removeInstance(String type) {
        // remove all instances of type "type"
        CourseInstance lastRemoved;
        for (int i = 0; i < classTimes.size(); i++) {
            if (classTimes.get(i).type.equals(type)) {
                lastRemoved = removeInstance(i);
                lastRemoved.printCI();
            }
        }
    }

    void removeInstance(int day, int hour, int minute) {
        CourseInstance lastRemoved;
        for (int i = 0; i < classTimes.size(); i++) {
            if (classTimes.get(i).day == day && classTimes.get(i).hour == hour && classTimes.get(i).minute == minute) {
                lastRemoved = removeInstance(i);
                lastRemoved.printCI();
            }
        }
    }

    void printCourseInfo() {
        System.out.println("Class name: " + name);
        System.out.println("Class Instances: ");
        // System.out.println(classTimes.length);
        for (int j = 0; j < numInstances; j++) {
            classTimes.get(j).printCI();
        }
        System.out.println("Class multiplier: " + multiplier);
        System.out.println("Number of Instances: " + numInstances);
    }

}

