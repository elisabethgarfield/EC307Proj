package ggkaw.caces.doby;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

public class NewClassPage extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_class_page);
    }

    public void addAndStore(View view) {
        TextView existingSections = (TextView) findViewById(R.id.Dynam_Text_View);
        Spinner classTypeSpin = (Spinner) findViewById(R.id.Class_Type_Drop);
        Spinner classDaySpin = (Spinner) findViewById(R.id.Day_Drop);
        Spinner AMPMStart = (Spinner) findViewById(R.id.AM_PM_Start_Spin);
        Spinner AMPMEnd = (Spinner) findViewById(R.id.AM_PM_End_Spin);

        EditText timeText = (EditText) findViewById(R.id.Time_Edit);
        EditText durationText = (EditText) findViewById(R.id.Duration_Edit);


        existingSections.append(classTypeSpin.getSelectedItem().toString());
        existingSections.append(" ");
        existingSections.append(classDaySpin.getSelectedItem().toString());
        existingSections.append(" ");
        existingSections.append(timeText.getText().toString());
        existingSections.append(AMPMStart.getSelectedItem().toString());
        existingSections.append(" to ");
        existingSections.append(durationText.getText().toString());
        existingSections.append(AMPMEnd.getSelectedItem().toString());
        existingSections.append("\n-------------\n");

    }
}
