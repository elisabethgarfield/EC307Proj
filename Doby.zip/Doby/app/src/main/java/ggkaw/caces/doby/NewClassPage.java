package ggkaw.caces.doby;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class NewClassPage extends AppCompatActivity {

    // declare the instance of Course class you will use
    Course createdCourse;
//    private static final String DEG_TAG = "Read DICK!";
//
//    private void writeToFile(String data, Context context) {
//        try {
//            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("config.txt", Context.MODE_PRIVATE));
//            outputStreamWriter.write(data);
//            outputStreamWriter.close();
//        }
//        catch (IOException e) {
//            Log.e("Exception", "File write failed: " + e.toString());
//        }
//    }
//    private String readFromFile(Context context) {
//
//        String ret = "";
//
//        try {
//            InputStream inputStream = context.openFileInput("config.txt");
//
//            if ( inputStream != null ) {
//                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
//                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
//                String receiveString = "";
//                StringBuilder stringBuilder = new StringBuilder();
//
//                while ( (receiveString = bufferedReader.readLine()) != null ) {
//                    stringBuilder.append(receiveString);
//                }
//
//                inputStream.close();
//                ret = stringBuilder.toString();
//            }
//        }
//        catch (FileNotFoundException e) {
//            Log.e("login activity", "File not found: " + e.toString());
//        } catch (IOException e) {
//            Log.e("login activity", "Can not read file: " + e.toString());
//        }
//
//        return ret;
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_class_page);
    }

    public void addAndStore(View view) {
        TextView existingSections = (TextView) findViewById(R.id.Dynam_Text_View);
        Spinner classTypeSpin = (Spinner) findViewById(R.id.Class_Type_Drop);
        Spinner classDaySpin = (Spinner) findViewById(R.id.Day_Drop);
        Spinner AMPMStart = (Spinner) findViewById(R.id.AM_PM_Start_Spin);
        Spinner AMPMEnd = (Spinner) findViewById(R.id.AM_PM_End_Spin);
        EditText timeText = (EditText) findViewById(R.id.Time_Edit);
        EditText durationText = (EditText) findViewById(R.id.Duration_Edit);

        String classType = classTypeSpin.getSelectedItem().toString();
        String classDay = classDaySpin.getSelectedItem().toString();
        String APStart = AMPMStart.getSelectedItem().toString();
        String APEnd = AMPMEnd.getSelectedItem().toString();
//        String


//        Context context = this;
//        writeToFile("Dick", context);
//        Log.d(DEG_TAG,readFromFile(context));

        // create new course instance and add it to the Course class
//        createdCourse.addInstance(CourseInstance());


        existingSections.append(classTypeSpin.getSelectedItem().toString());
        existingSections.append(" ");
        existingSections.append(classDaySpin.getSelectedItem().toString());
        existingSections.append(" ");
        existingSections.append(timeText.getText().toString());
        existingSections.append(AMPMStart.getSelectedItem().toString());
        existingSections.append(" to ");
        existingSections.append(durationText.getText().toString());
        existingSections.append(AMPMEnd.getSelectedItem().toString());
        existingSections.append("\n-------------\n");

    }

    public void SetNewClass(View view) {
        String courseName = findViewById(R.id.Class_Name_Edit).toString();
        String multiplier = findViewById(R.id.multiplier).toString();
        String startDate = findViewById(R.id.Start_Date_Edit).toString();
        String endDate = findViewById(R.id.End_Date_Edit).toString();
        createdCourse = new Course(courseName, Double.parseDouble(multiplier), startDate, endDate); // CREATE NEW CONSTRUCTOR w/ 2 args
    }
}
